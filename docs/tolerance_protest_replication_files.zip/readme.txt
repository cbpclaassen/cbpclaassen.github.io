This folder includes data and R code to replicate the results in  *Does Intolerance Dampen Dissent? Macro-Tolerance and Protest in American Metropolitan Areas*

Note that the microlevel survey data from the Freedom and Tolerance surveys cannot be made publicly available with the metropolitan (MSA) identifiers included. Doing so poses a risk to the anonymity of the survey respondents. 

The MSA estimates of tolerance are included along with the other MSA-level data. 

Data sources are listed in the online supplementary materials, table A4.