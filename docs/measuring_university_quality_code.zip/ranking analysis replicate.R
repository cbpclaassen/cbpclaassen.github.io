##### Measuring University Quality
##### R code

library(psych)
library(lavaan)
library(MCMCpack)
library(EstCRM)
library(rstan)
set_cppo("fast")  # for best running speed
library(RColorBrewer)
library(AID)
library(parallel)
library(plyr)



setwd("/Users/christopherclaassen/Documents/Research/University Rankings")

rankdat <- read.csv("globalrank_all.csv")
cugdat <- read.csv("cug_uk_recode_14.csv")
parchdat <- read.csv("parch_us_14.csv")
usndat <- read.csv("usn_nu_15_recode.csv")


# Reshape data

rankdat1 <- merge(rankdat, cugdat, by.x = "NameR", by.y = "Name", all = TRUE, suffixes = c("", ".cug"))
rankdat2 <- merge(rankdat1, usndat, by.x = "NameR", by.y = "Name", all = TRUE, 
                  suffixes = c("", ".usn.nu"))
rankdat2$Score.usn.nu <- rankdat2$Score
rankdat2$Score <- NULL

rankdat2$NameR[duplicated(rankdat2$NameR)]


# Add country

rankdat2[is.na(rankdat2$Score.cug) == FALSE, "Country"] <- "UK"
rankdat2[is.na(rankdat2$Score.usn.nu) == FALSE, "Country"] <- "USA"

small.cnt <- names(sort(summary(rankdat2$Country)))[1:34]  # all countries with < 5 univs
rankdat2$Country.simp <- as.character(rankdat2$Country)
rankdat2$Country.simp[rankdat2$Country %in% small.cnt] <- "Other"
rankdat2$Country.simp[is.na(rankdat2$Country)] <- "Other"
rankdat2$Country.simp <- as.factor(rankdat2$Country.simp)

rankdat2$Country <- NULL
rankdat2$Country.cug <- NULL
rankdat2$Country.usn.nu <- NULL

round(cor(rankdat2[,2:9], use = "pair"), 2)
eigen(cor(rankdat2[,2:7], use = "pair"))$values
eigen(cor(rankdat2[,2:7], use = "compl"))$values
fa(cor(rankdat2[,2:7], use = "pair"))$loadings
fa(cor(rankdat2[,2:7], use = "compl"))$loadings

# plot ratings

plot.nam <- c("Shanghai", "THE", "Jeddah", "USN-GU", "QS", "Webometrics", "CUG", "USN-NU")
pdf("rating_dist_pre.pdf", width = 6, height = 4)
par(mfrow = c(2,4), mar = c(2, 1, 2, 1))
for (i in 1:8) {
  hist(rankdat2[, (1+i)], yaxt = "n", xaxt = "n", ann = FALSE)
  axis(1, cex.axis = 0.7, tick = 0.1, mgp = c(1.4, .3, 0), tcl = -0.3, line = 0)
  mtext(plot.nam[i], 3, .5, cex = 0.7)
}
dev.off()


# rescale X vars

xdat1 <- rankdat2[,2:9]
for(i in 1:8) {
  xdat1[,i] <- scale(xdat1[,i])[,1]
}
xdat1[,1] <- log(xdat1[,1] - min(xdat1[,1], na.rm = TRUE) + 0.1)
xdat1[,2] <- log(xdat1[,2] - min(xdat1[,2], na.rm = TRUE) + 1)
xdat1[,3] <- log(xdat1[,3] - min(xdat1[,3], na.rm = TRUE) + 0.01)
xdat1[,4] <- log(xdat1[,4] - min(xdat1[,4], na.rm = TRUE) + 1)
xdat1[,5] <- log(xdat1[,5] - min(xdat1[,5], na.rm = TRUE) + 1)
xdat1[,6] <- log(xdat1[,6] - min(xdat1[,6], na.rm = TRUE) + 1)
xdat1[,8] <- log(xdat1[,8] - min(xdat1[,8], na.rm = TRUE) + 1)
for(i in 1:8) {
  xdat1[,i] <- scale(xdat1[,i])[,1]
}

colnames(xdat1) <- c("sjt", "the", "jed", "usn.gu", "qs", "wb", "cug", "usn.nu")
rankdat3 <- data.frame(NameR = rankdat2$NameR, xdat1, Country.simp = rankdat2$Country.simp)
summary(rankdat3)

pdf("rating_dist_post.pdf", width = 6, height = 4)
par(mfrow = c(2,4), mar = c(2, 1, 2, 1))
for (i in 1:8) {
  hist(rankdat3[, (1+i)], yaxt = "n", xaxt = "n", ann = FALSE)
  axis(1, cex.axis = 0.7, tick = 0.1, mgp = c(1.4, .3, 0), tcl = -0.3, line = 0)
  mtext(plot.nam[i], 3, .5, cex = 0.7)
}
dev.off()

cor1 <- corr.test(rankdat3[, 2:9], use = "pairwise")
lowerMat(cor1$r, digits = 2)
lowerMat(cor1$n, digits = 2)


# plot eigenvalues

sim.val <- fa.parallel(cor(rankdat3[, 2:7], use = "pair"))$pc.sim
pdf("eigen.pdf", width = 3.5, height = 3.5)
par(mfrow = c(1,1), mar = c(2.5, 2.5, .5, .5))
plot(eigen(cor(rankdat3[, 2:7], use = "pair"))$values, type = "b", las = 1, cex.axis = 0.68,
     cex.lab = 0.75, mgp = c(1.4, .6, 0), tcl = -0.3, xlab = "Dimensions", ylab = "Eigenvalue",
     xaxt = "n", cex = 0.8, pch = 20)
rect(0.8, -0.2, 6.2, 4.9, col = grey(0.8), border = NA)
abline(h = 0:4, col = "white", lwd = 0.75)
points(eigen(cor(rankdat3[, 2:7], use = "pair"))$values, type = "b", pch = 20, lwd = 1.5)
lines(1:6, sim.val, lty = 2, lwd = 1.5)
axis(1, cex.axis = 0.68, tick = 0.1, mgp = c(1.4, .3, 0), tcl = -0.3, line = 0)
dev.off()



rank.stack <- reshape(rankdat3, idvar = "NameR", ids = rankdat3$NameR, direction = "long", 
                      times = names(rankdat3)[2:9], timevar = "Variables", 
                      varying = list(names(rankdat3)[2:9]))
names(rank.stack)[4] <- "Score"

rank.stack <- rank.stack[is.na(rank.stack$Score) == FALSE, ]  # remove cases of no ratings

(n.univ <- max(as.numeric(factor(rank.stack$NameR))))
(harv <- unique(as.numeric(factor(rank.stack$NameR)[rank.stack$NameR == "Harvard"])))
(n.raters <- max(as.numeric(factor(rank.stack$Variables))))
(n.ratings <- length(rank.stack$Score))
(n.cnt <- length(unique(rank.stack$Country.simp)))
(n.rat.cnt <- length(unique(interaction(as.numeric(factor(rank.stack$Country)), 
                                        as.numeric(factor(rank.stack$Variables))))))
(usa <- unique(as.numeric(factor(rank.stack$Country)[rank.stack$Country == "USA"])))




## Stan model

# data
univs <- as.numeric(factor(rank.stack$NameR))
raters <- as.numeric(factor(rank.stack$Variables))
cntrys <- as.numeric(factor(rank.stack$Country))
rat.cnt <- as.numeric(interaction(as.numeric(factor(rank.stack$Country)), 
                                  as.numeric(factor(rank.stack$Variables)), 
                                  drop = TRUE))

cntr.stack <- reshape(rankdat3, idvar = "NameR", ids = rankdat3$NameR, direction = "long", 
                      times = "Country.simp", varying = list("Country.simp"))
temp <- apply(cntr.stack[,2:9], 2, is.na)
cntr.stack <- cntr.stack[(rowSums(temp) == 8) == FALSE, ]  # remove cases of no ratings
cntr.univ <- as.numeric(factor(cntr.stack$Country.simp))

dat <- list(J = n.raters, K = n.ratings, M = n.cnt, N = n.univ, MJ = max(rat.cnt),
            ii = univs, jj = raters, mm = cntrys, mj = rat.cnt, mu_Beta = c(0, 0),
            mu_Beta1 = c(0, 0), mu_Beta2 = c(0, 0), mu_Gamma = c(0, 0), 
            x = rank.stack$Score, eta_1 = rep(1, n.univ), Beta1_val = c(0, 1),
            eta1_int = rep(1, n.univ), eta2_int = rep(1, n.cnt))

# inits
initf20 <- function() {
  list(Beta = cbind(rep(0, n.raters), rep(2, n.raters)), Omega_Beta = diag(2),  
       tau_Beta = c(1, 1), eta = rep(0, n.univ), sigma_x = rep(1, n.raters)) }

# pars
pars.bfa20 <- c("Beta", "sigma_x", "Omega_Beta", "Sigma_Beta", "eta", "x_hat", "x_pred")

# models
stan.mod.20 <- stan(file = 'bfa20.stan', data = dat, iter = 20, chains = 1, init = initf20, 
                    pars = pars.bfa20) 
par.20 <- mclapply(1:4, mc.cores = 2, function(i) { 
  stan(fit = stan.mod.20, data = dat, iter = 2000, init = initf20, pars = pars.bfa20, 
       chains = 1, chain_id = i, refresh = -1) 
  } )
stan.mod.20 <- sflist2stanfit(par.20)


# output
stan.out <- summary(stan.mod.20)
stan.samp <- as.matrix(stan.mod.20)
dim(stan.out$summary)
round(stan.out$summary[1:32, c(1, 3)], 2)
round(stan.out$summary[1:75,], 2)

traceplot(stan.mod.20, c("Beta[1,1]", "Beta[1,2]", "Beta[7,1]", "Beta[7,2]", "Omega_Beta[1,2]", 
                         "eta[408]"), ncol = 3, nrow = 2)

# save loadings and factor scores
round(load <- data.frame(stan.out$summary[ (1:n.raters) * 2, ], 
                         row.names = sort(unique(rank.stack$Variables))), 2)
round(intr <- data.frame(stan.out$summary[ (1:n.raters) * 2 - 1, ], 
                         row.names = sort(unique(rank.stack$Variables))), 2)
round(sigm <- data.frame(stan.out$summary[(n.raters*2+1):(n.raters*3), ], 
                         row.names = sort(unique(rank.stack$Variables))), 2)
scor <- data.frame(stan.out$summary[ (n.raters*3+8+1) : (n.raters*3+8+n.univ), ], 
                   row.names = sort(unique(rank.stack$NameR)))
cbind(row.names(scor)[order(scor$mean, decreasing = TRUE)[1:50]], 
      scor[order(scor$mean, decreasing = TRUE)[1:50], "mean"])


# save data
#write.csv(stan.out, "bfa20.summary.csv")
#write.csv(stan.samp, "bfa20.samples.csv", row.names = FALSE)
#write.csv(load, "bfa20.loadings.csv")
#write.csv(cntr, "bfa21.countries.csv")

# Plot
score <- scor[order(scor$mean, decreasing = TRUE), ]
sc.max <- round(max(scor[,6]) + 1, 0)
sc.min <- round(min(scor[,6]) + 0, 0)

pdf("glob_rank_200.pdf", width = 6, height = 8.5)
par(mfrow = c(1, 2), mar = c(0, 6, 0, 0))
for (i in 1:2) {
  plot(score[(1+(i-1)*100):(i*100), 6], 100:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
       xaxt = "n", bty = "n", xlim = c(sc.min, sc.max), ylim = c(1, 100), cex = 0.8)
  rect(sc.min, 0, sc.max, 100.5, col = grey(0.8), border = NA)
  segments(x0 = -2:6, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 2, col = "white")
  segments(x0 = 0, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 1, col = "white")
  axis(1, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0, 0), tcl = -0.2, line = -1.15)
  axis(3, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0.2, 0), tcl = -0.2, line = -1.33)
  axis(2, at = 100:1, cex.axis = 0.42, las = 1, tick = FALSE, line = -0.8,
       labels = paste((1+(i-1)*100):(i*100), row.names(score)[(1+(i-1)*100):(i*100)]))
  segments(x0 = score[(1+(i-1)*100):(i*100), 4], x1 = score[(1+(i-1)*100):(i*100), 8], 
           y0 = 100:1, lwd = 1.25)
  points(score[(1+(i-1)*100):(i*100), 6], 100:1, pch = 20, cex = 0.8)
}
dev.off()

pdf("glob_rank_400.pdf", width = 6, height = 8.5)
par(mfrow = c(1, 2), mar = c(0, 6, 0, 0))
for (i in 3:4) {
  plot(score[(1+(i-1)*100):(i*100), 6], 100:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
       xaxt = "n", bty = "n", xlim = c(sc.min, sc.max), ylim = c(1, 100), cex = 0.8)
  rect(sc.min, 0, sc.max, 100.5, col = grey(0.8), border = NA)
  segments(x0 = -2:6, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 2, col = "white")
  segments(x0 = 0, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 1, col = "white")
  axis(1, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0, 0), tcl = -0.2, line = -1.15)
  axis(3, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0.2, 0), tcl = -0.2, line = -1.33)
  axis(2, at = 100:1, cex.axis = 0.42, las = 1, tick = FALSE, line = -0.8,
       labels = paste((1+(i-1)*100):(i*100), row.names(score)[(1+(i-1)*100):(i*100)]))
  segments(x0 = score[(1+(i-1)*100):(i*100), 4], x1 = score[(1+(i-1)*100):(i*100), 8], 
           y0 = 100:1, lwd = 1.25)
  points(score[(1+(i-1)*100):(i*100), 6], 100:1, pch = 20, cex = 0.8)
}
dev.off()

pdf("glob_rank_600.pdf", width = 6, height = 8.5)
par(mfrow = c(1, 2), mar = c(0, 6, 0, 0))
for (i in 5:6) {
  plot(score[(1+(i-1)*100):(i*100), 6], 100:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
       xaxt = "n", bty = "n", xlim = c(sc.min, sc.max), ylim = c(1, 100), cex = 0.8)
  rect(sc.min, 0, sc.max, 100.5, col = grey(0.8), border = NA)
  segments(x0 = -2:6, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 2, col = "white")
  segments(x0 = 0, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 1, col = "white")
  axis(1, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0, 0), tcl = -0.2, line = -1.15)
  axis(3, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0.2, 0), tcl = -0.2, line = -1.33)
  axis(2, at = 100:1, cex.axis = 0.42, las = 1, tick = FALSE, line = -0.8,
       labels = paste((1+(i-1)*100):(i*100), row.names(score)[(1+(i-1)*100):(i*100)]))
  segments(x0 = score[(1+(i-1)*100):(i*100), 4], x1 = score[(1+(i-1)*100):(i*100), 8], 
           y0 = 100:1, lwd = 1.25)
  points(score[(1+(i-1)*100):(i*100), 6], 100:1, pch = 20, cex = 0.8)
}
dev.off()



## Plot loadings

rat.nam <- c("CUG", "Jeddah", "QS", "Shanghai", "THE", "USN-GU", "USN-NU", "Webometrics")
row.names(load) <- rat.nam
load.ord <- load[order(load$mean, decreasing = TRUE), ]
min.load <- min(load.ord[,4]) - 0.1
max.load <- max(load.ord[,8]) + 0.1

#pdf("loadings.pdf", width = 3, height = 2.5)
pdf("loadings_nocnt.pdf", width = 3, height = 2.5)
par(mfrow = c(1, 1), mar = c(1.2, 4, 0.5, 0.5))
plot(load.ord[,6], 8:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
     xaxt = "n", bty = "n", ylim = c(1, 8), xlim = c(min.load, max.load))
rect(min.load, 0, max.load, 8.5, col = grey(0.8), border = NA)
segments(x0 = c(.6, .8, 1, 1.2, 1.4, 1.6, 1.8), y0 = 0, y1 = 8.5, lwd = 0.75, lty = 1, col = "white")
axis(1, cex.axis = 0.7, mgp = c(1.5, 0.2, 0), tcl = -0.3, line = 0)
axis(2, at = 8:1, cex.axis = 0.7, las = 1, tick = FALSE, line = -0.8, labels = row.names(load.ord))
segments(x0 = load.ord[,4], x1 = load.ord[,8], y0 = 8:1, lwd = 1.25)
points(load.ord[,6], 8:1, pch = 20)
dev.off()


## Error variance and R-sq

row.names(sigm) <- rat.nam
sigm.ord <- sigm[order(sigm$X50., decreasing = FALSE), ]
min.sigm <- min(sigm.ord[,4]) - 0.1
max.sigm <- max(sigm.ord[,8]) + 0.1

adj.r2 <- matrix(NA, ncol = 3, nrow = 8)
for(i in 1:8) {
  adj.r2[i,1] <- 1 - sigm.ord[i,1]^2
  adj.r2[i,2] <- 1 - sigm.ord[i,4]^2
  adj.r2[i,3] <- 1 - sigm.ord[i,8]^2
}
min.r2 <- min(adj.r2[,3]) - 0.1
max.r2 <- max(adj.r2[,2]) + 0.1



pdf("rater_effects.pdf", width = 6, height = 3)
mat.lay <- matrix(c(1, 2), ncol = 2, nrow = 1)
layout(mat.lay, widths = c(.55, .43))
par(mar = c(2.5, 4, 0.5, 0.5))
plot(sigm.ord[,6], 8:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
     xaxt = "n", bty = "n", ylim = c(1, 8), xlim = c(0, 1))
rect(0, 0, 1, 8.5, col = grey(0.8), border = NA)
segments(x0 = seq(.2, .8, by = .2), y0 = 0, y1 = 8.5, lwd = 0.75, lty = 2, col = "white")
axis(1, cex.axis = 0.6, mgp = c(1.5, 0.2, 0), tcl = -0.3, line = 0)
axis(2, at = 8:1, cex.axis = 0.65, las = 1, tick = FALSE, line = -0.8, labels = row.names(sigm.ord))
mtext("Standard deviation of rater error", 1, 1.2, cex = 0.75)
segments(x0 = sigm.ord[,4], x1 = sigm.ord[,8], y0 = 8:1, lwd = 1.25)
points(sigm.ord[,6], 8:1, pch = 20)
# plot 2
par(mar = c(2.5, 0.5, 0.5, 0.5))
plot(adj.r2[,1], 8:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
     xaxt = "n", bty = "n", ylim = c(1, 8), xlim = c(0, max.r2))
rect(0, 0, 1, 8.5, col = grey(0.8), border = NA)
segments(x0 = seq(.2, .8, by = .2), y0 = 0, y1 = 8.5, lwd = 0.75, lty = 2, col = "white")
axis(1, cex.axis = 0.6, mgp = c(1.5, 0.2, 0), tcl = -0.3, line = 0)
mtext("Adjusted R-squared", 1, 1.2, cex = 0.75)
segments(x0 = adj.r2[,2], x1 = adj.r2[,3], y0 = 8:1, lwd = 1.25)
points(adj.r2[,1], 8:1, pch = 20)
dev.off()


## Plot intercepts, loadings and data

x.hat <- stan.out$summary[(n.raters*3+8+n.univ+1):(n.raters*3+8+n.univ+n.ratings), 1]

pdf("int_slopes.pdf", width = 4, height = 4)
par(mfrow = c(1, 1), mar = c(2.5, 2.5, 0.5, 0.5))
plot(scor[univs,1], rank.stack$Score, type = "p", pch = 20, col = "white", ylab = "", xlab = "", 
     xaxt = "n", yaxt = "n")
abline(h = 0, lty = 2, lwd = .75)
abline(v = 0, lty = 2, lwd = .75)
points(scor[univs,1], rank.stack$Score, pch = 20, col = rgb(.5, .5, .5, .2))
for(i in 1:n.raters) {
  abline(a = intr[i,1], b = load[i,1], col = brewer.pal(8, "Dark2")[i], lwd = 2)
}
axis(1, cex.axis = 0.6, mgp = c(1.5, 0.3, 0), tcl = -0.3, line = 0)
axis(2, cex.axis = 0.6, mgp = c(1.5, 0.5, 0), tcl = -0.3, line = 0, las = 1)
mtext("Quality estimates", 1, 1.1, cex = 0.75)
mtext("Logged and normalized observed ratings", 2, 1.4, cex = 0.75)
legend("topleft", legend = rat.nam, col = brewer.pal(8, "Dark2"), lwd = 2, bty = "n", 
       cex = 0.6)
dev.off()



## Examine residuals by country and rating system

x.hat <- stan.out$summary[(n.raters*3+8+n.univ+1):(n.raters*3+8+n.univ+n.ratings), 1]
x.pred <- as.matrix(stan.mod.20)[ ,(n.raters*3+8+n.univ+n.ratings+1):(n.raters*3+8+n.univ+n.ratings*2) ] 
resid <- rank.stack$Score - x.hat
real.resid <- apply(x.pred, 1, function(x) rank.stack$Score - x)

rat.nam <- c("CUG", "Jeddah", "QS", "Shanghai", "THE", "USN-GU", "USN-NU", "Webometrics")
cnt.nam <- levels(factor(rank.stack$Country))

rat.res.est <- tapply(apply(real.resid, 1, mean), raters, mean)
names(rat.res.est) <- rat.nam
round(rat.res.est, 2)

cnt.res.est <- tapply(apply(real.resid, 1, mean), cntrys, mean)
names(cnt.res.est) <- cnt.nam
round(cnt.res.est, 2)

cnt.rat.res.est <- tapply(apply(real.resid, 1, mean), list(cntrys, raters), mean)
colnames(cnt.rat.res.est) <- rat.nam
rownames(cnt.rat.res.est) <- cnt.nam
round(cnt.rat.res.est, 2)

cnt.rat.res.l95 <- matrix(NA, ncol = 8, nrow = 44)
cnt.rat.res.u95 <- matrix(NA, ncol = 8, nrow = 44)
cnt.rat.n <- xtabs( ~ cntrys + raters)

for (i in 1:44) {    # countries
  for (j in 1:8) {   # rating systems
    cnt.rat.res.l95[i, j] <- ifelse(cnt.rat.n[i,j] == 1, 
                                    quantile(real.resid[(cntrys == i & raters == j),], probs = 0.025),
                                    quantile(apply(real.resid[(cntrys == i & raters == j),], 2, mean),
                                             probs = 0.025, na.rm = TRUE))
    cnt.rat.res.u95[i, j] <- ifelse(cnt.rat.n[i,j] == 1, 
                                    quantile(real.resid[(cntrys == i & raters == j),], probs = 0.975),
                                    quantile(apply(real.resid[(cntrys == i & raters == j),], 2, mean),
                                             probs = 0.975, na.rm = TRUE))
  }
}

hm.cnt.est <- c(cnt.rat.res.est[34,2], cnt.rat.res.est[43,3], cnt.rat.res.est[43,5], 
                cnt.rat.res.est[44,6], cnt.rat.res.est[37,8])
hm.cnt.l95 <- c(cnt.rat.res.l95[34,2], cnt.rat.res.l95[43,3], cnt.rat.res.l95[43,5], 
                cnt.rat.res.l95[44,6], cnt.rat.res.l95[37,8])
hm.cnt.u95 <- c(cnt.rat.res.u95[34,2], cnt.rat.res.u95[43,3], cnt.rat.res.u95[43,5], 
                cnt.rat.res.u95[44,6], cnt.rat.res.u95[37,8])

cnt.bias.nam <- c("Jeddah\n(Saudi Arabia)", "QS\n(UK)", "THE\n(UK)", "USN-GU\n(USA)", 
                  "Webometrics\n(Spain)")
pdf("home_country_effects.pdf", width = 3, height = 3)
par(mar = c(2.5, 4, 0.5, 0.5))
plot(hm.cnt.est, 5:1, type = "p", pch = 20, xlab = "", ylab = "", yaxt = "n", 
     xaxt = "n", bty = "n", ylim = c(1, 5), xlim = c(-1, 1))
rect(-1, 0, 1, 5.5, col = grey(0.8), border = NA)
segments(x0 = seq(-.75, .75, by = .25), y0 = 0, y1 = 5.5, lwd = 0.75, lty = 2, col = "white")
segments(x0 = 0, y0 = 0, y1 = 5.5, lwd = 0.75, lty = 1, col = "white")
axis(1, cex.axis = 0.6, mgp = c(1.5, 0.2, 0), tcl = -0.3, line = 0)
axis(2, at = 5:1, cex.axis = 0.65, las = 1, tick = FALSE, line = -0.8, labels = cnt.bias.nam)
mtext("Home country bias by rating system", 1, 1.2, cex = 0.75)
segments(x0 = hm.cnt.l95, x1 = hm.cnt.u95, y0 = 5:1, lwd = 1.25)
points(hm.cnt.est, 5:1, pch = 20)
dev.off()


## Biggest countries

big.cnt.nam <- names(sort(xtabs(~ rank.stack$Country), decreasing = TRUE))[c(1:10, 12:16)]

big.cnt.rat.est <- cnt.rat.res.est[ cnt.nam %in% big.cnt.nam , c(2:6, 8) ]
round(big.cnt.rat.est, 2)


## Plot of prob of being in top 100

# rank each university in each sample
scor.samp <- stan.samp[,33:(32+n.univ)]
#scor.samp <- stan.samp[,75:(74+n.univ)]
#scor.samp <- stan.samp[,23:(22+n.univ)]
rank.samp <- scor.samp
for (i in 1:4000) {
  rank.samp[i,] <- n.univ - as.numeric(rank(scor.samp[i,]))
}
# count no. of times ranked top 100
t100.samp <- scor$mean
for (i in 1:n.univ) {
  temp <- rank.samp
  temp[,i] <- ifelse(rank.samp[,i] < 101, 1, 0)
  t100.samp[i] <- sum(temp[,i])
}
(t100.samp <- t100.samp / 40)
names(t100.samp) <- row.names(scor)
t100.sort <- t100.samp[order(scor$mean, decreasing = TRUE)]

# plot
# pdf("prob_top100.pdf", width = 6, height = 8.5)
pdf("prob_top100_nocnt.pdf", width = 6, height = 8.5)
par(mfrow = c(1, 2), mar = c(0, 6, 0, 0))
for (i in 1:2) {
  plot(t100.sort[(1+(i-1)*100):(i*100)], 100:1, type = "p", pch = 20, xlab = "", ylab = "", 
       yaxt = "n", xaxt = "n", bty = "n", xlim = c(0, 100), ylim = c(1, 100), cex = 0.8)
  rect(-0.5, 0, 100, 100.5, col = grey(0.8), border = NA)
  rect(-0.5, 0, 5, 100.5, col = grey(0.5), border = NA)
  segments(x0 = c(25, 50, 75), y0 = 0, y1 = 100.5, lwd = 0.75, lty = 2, col = "white")
    segments(x0 = 5, y0 = 0, y1 = 100.5, lwd = 0.75, lty = 1, col = "white")
  axis(1, at = c(0, 25, 50, 75, 100), cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0, 0), 
       tcl = -0.2, line = -1.15)
  axis(3, at = c(0, 25, 50, 75, 100), cex.axis = 0.6, tick = 0.1, mgp = c(1.5, 0.2, 0), 
       tcl = -0.2, line = -1.33)
  axis(2, at = 100:1, cex.axis = 0.42, las = 1, tick = FALSE, line = -0.8,
       labels = paste((1+(i-1)*100):(i*100), names(t100.sort)[(1+(i-1)*100):(i*100)]))
  points(t100.sort[(1+(i-1)*100):(i*100)], 100:1, pch = 20, cex = 0.8)
  lines(t100.sort[(1+(i-1)*100):(i*100)], 100:1, cex = 0.8)
}
dev.off()

  


## Model checking

# ratings vs. fitted ratings
x.hat <- stan.out$summary[(n.raters*3+8+n.univ+1):(n.raters*3+8+n.univ+n.ratings), 1]

par(mfrow = c(1,2))
plot(x.hat, rank.stack$Score, pch = 20, col = rgb(0, 0, 0, 0.2), cex = 0.6)
plot(x.hat, rank.stack$Score, pch = ".", col = "white")
for(i in 1:n.raters) {
  points(x.hat[raters==i], rank.stack$Score[raters==i], pch = ".", 
       col = brewer.pal(8, "Dark2")[i])
  lines(lowess(x.hat[raters==i], rank.stack$Score[raters==i]), col = brewer.pal(8, "Dark2")[i])
  legend("bottomright", legend = row.names(load), fill = brewer.pal(8, "Dark2"), 
         cex = 0.6, pt.cex = 0.6)
}


## Residual analysis and plots

# posterior predictive checks

post.inds <- round(runif(9, 1, 4000), 0)
x.pred.9 <- as.matrix(stan.mod.20)[ post.inds, 
    (n.raters*3+8+n.univ+n.ratings+1):(n.raters*3+8+n.univ+n.ratings*2) ]  
resid <- rank.stack$Score - x.hat

summary(aov(resid ~ factor(raters)))
summary(aov(resid ~ factor(univs)))
summary(aov(resid ~ factor(cntrys)))

par(mfrow = c(1,2))
plot(resid, pch = 20, col = rgb(0, 0, 0, 0.2), cex = 0.6, mgp = c(1.5, .7, 0))
plot(x.hat, resid, pch = 20, col = rgb(0, 0, 0, 0.2), cex = 0.6, mgp = c(1.5, .7, 0))


# plot predicted vs actual ratings

par(mfrow = c(3, 3), mar = c(4, 4, 1, 1))
for(i in 1:9) {
  plot(x.pred.9[i,], rank.stack$Score, pch = 20, col = rgb(0, 0, 0, 0.25), mgp = c(1.5, 0.7, 0))
  lines(lowess(x.pred[i,], rank.stack$Score), col = "blue")
  abline(a = 0, b = 1, lty = 3)
}

pdf("post_checks_ratings.pdf", width = 6.5, height = 4.5)
par(mfrow = c(3, 3), mar = c(2.5, 2.5, .5, .5))
for(i in 1:8) {
  hist(x.pred.9[i,], mgp = c(1.5, 0.7, 0), yaxt = "n", ylab = "", xlab = "", main = "", 
       ylim = c(0, 750), cex.axis = 0.8)
  text(2, 700, paste0("y_sim ", "[", post.inds[i], "]"), cex = 0.8)
}
hist(rank.stack$Score, mgp = c(1.5, 0.7, 0), yaxt = "n", ylab = "", xlab = "", main = "", 
     ylim = c(0, 750), cex.axis = 0.8)
text(2, 700, "y_obs", cex = 0.8)
dev.off()


# plot realized residuals

real.resid <- apply(x.pred, 1, function(x) rank.stack$Score - x)

pdf("post_checks_resid.pdf", width = 6.5, height = 4.5)
par(mfrow = c(3, 3), mar = c(2.5, 2.5, .5, .5))
for(i in 1:9) {
  plot(rank.stack$Score, real.resid[, post.inds[i]], pch = 20, mgp = c(1.5, 0.7, 0), ylab = "", 
       xlab = "", bty = "n", main = "", cex = 0.5, cex.axis = 0.8, col = rgb(0, 0, 0, 0.2), 
       xaxt = "n", yaxt = "n", ylim = c(-4.5, 5))
  text(2, 3, paste0("y_sim ", "[", post.inds[i], "]"), cex = 0.7)
  lines(lowess(rank.stack$Score, real.resid[, post.inds[i]]), col = "blue")
  axis(1, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, .3, 0), tcl = -0.2, line = 0)
  axis(2, cex.axis = 0.6, tick = 0.1, mgp = c(1.5, .4, 0), tcl = -0.2, line = 0, las = 1)
}
dev.off()



# plot distribution of quality estimates

scor.samp <- as.matrix(stan.mod.20)[post.inds, (n.raters*3+8+1) : (n.raters*3+8+n.univ) ]
par(mfrow = c(2, 4), mar = c(3, 3, .5, .5))
for(i in 1:8) {
  hist(scor.samp[i,], mgp = c(1.5, 0.7, 0), yaxt = "n", ylab = "", xlab = "", main = "")
}

# correlations
x.pred.inds <- list()
for(i in 1:100) {
  temp <- data.frame(ratings = x.pred[i,], univs, raters)
  temp$raters <- factor(temp$raters, 
                        labels = c("cug", "jed", "qs", "sjt", "the", "usn-gu", "usn-nu", "wb"))
  temp1 <- reshape(temp, direction = "wide", idvar = "univs", timevar = "raters")
  x.pred.inds[[i]] <- temp1
}

round(cor.pred <- cor(x.pred.inds[[100]][,2:9], use = "pair"), 2)
round(cor.obs <- cor(rankdat3[,2:9], use = "pair"), 2)

cor.pred.all <- sapply(x.pred.inds, function(x) cor(x[,2:9], use = "pair"))
cor.pred.95 <- apply(cor.pred.all, 1, quantile, probs = c(0.025, 0.975), na.rm = TRUE)

# plot
par(mfrow = c(1, 1))
plot(rowMeans(cor.pred.all), 1:64, type = "p", pch = 20, xlim = c(0, 1), ylim = c(1, 64),
     mgp = c(1.5, .7, 0), cex = 1)
segments(x0 = cor.pred.95[1,], y0 = 1:64, x1 = cor.pred.95[2,], lwd = 2, col = grey(0.4))
points(as.vector(cor.obs), 1:64, pch = "+", cex = 0.8)
abline(h = 1:64, col = grey(0.6), lty = 3)


## correlations between latent variable and ratings
scor <- data.frame(score = stan.out[ (n.raters*3+8+1) : (n.raters*3+8+n.univ), 1], 
                   names = sort(unique(rank.stack$NameR)))
rat.wide <- reshape(rank.stack, direction = "wide", idvar = "NameR", timevar = "Variables")
rat.wide <- rat.wide[, c(1, 3, 5, 7, 9, 11, 13, 15, 17)]
cor.dat <- merge(rat.wide, scor, by.x = "NameR", by.y = "names")
cor(cor.dat[,2:10], use = "pair")[9,]

